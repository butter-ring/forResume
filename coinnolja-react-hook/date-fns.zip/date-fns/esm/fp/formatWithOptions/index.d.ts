// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { formatWithOptions } from 'date-fns/fp'
export = formatWithOptions
