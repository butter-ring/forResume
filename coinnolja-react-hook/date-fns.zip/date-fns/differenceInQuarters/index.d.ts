// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { differenceInQuarters } from 'date-fns'
export = differenceInQuarters
