// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { differenceInCalendarWeeks } from 'date-fns'
export = differenceInCalendarWeeks
