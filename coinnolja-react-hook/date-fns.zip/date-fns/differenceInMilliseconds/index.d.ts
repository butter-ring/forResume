// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { differenceInMilliseconds } from 'date-fns'
export = differenceInMilliseconds
