// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { differenceInHours } from 'date-fns'
export = differenceInHours
