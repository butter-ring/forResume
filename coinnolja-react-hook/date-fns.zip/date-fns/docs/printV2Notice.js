console.log(`
🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥

  Thank you for testing (⩗) date-fns v2!

  In v2 we've introduced a number of breaking changes
  that make date-fns even more consistent and reliable.
  Please read the changelog carefully: https://git.io/fxCWb

  Please support us at Open Collective: https://opencollective.com/date-fns

🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥
`)
