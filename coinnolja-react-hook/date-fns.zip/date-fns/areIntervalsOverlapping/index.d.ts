// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { areIntervalsOverlapping } from 'date-fns'
export = areIntervalsOverlapping
